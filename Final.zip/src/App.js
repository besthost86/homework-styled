import { useState, useEffect, useContext } from "react";
import logo from "./logo.svg";
import "./App.css";

// function useState(defaultValue) {
//   let value = defaultValue;

//   const updateValue = (newValue) => {
//     value = newValue;
//   };

//   return [value, updateValue];
// }
const positions = ["Game", "Analytics", "DevOps", "Support", "Testing"];
const technologies = [
  "Javascript",
  "Angular",
  "React",
  "Vue",
  "Svelte",
  "Backbone",
  "AngularJS",
  "Ember",
];

// <td>ID</td>
// <td>NAME</td>
// <td>POSITION</td>
// <td>TECHNOLOGIES</td>
// <td>REMOTE</td>
// <td>PRICE RANGE</td>

function App({ offers }) {
  const [activePosition, setActivePosition] = useState("");
  const [activeTechnologies, setActiveTechnologies] = useState([]);
  const [filterState, setFilterState] = useState({
    seniority: "all",
    remote: false,
    priceRange: false,
  });

  // const handleClick = (event) => {
  //   setActivePosition(event.target.innerHTML);
  //   console.log("click", activePosition);
  // };

  // if (activePosition === "Support") {
  //   return null;
  // }

  // ['a', 'b', 'c']

  // every re-render

  useEffect(() => {
    console.log("every re-render");
  });

  // componentDidMount
  useEffect(() => {
    console.log("dom");
    const id = setInterval(() => console.log("interval"), 2000);

    return () => {
      clearInterval(id);
    };
  }, []);

  // fetchowanie i paginacja backendowa
  // useEffect(() => {
  //   // const data = fetch(`api?page=${pageNumber}`)
  //   // setFilterState(data)
  //   console.log("active technologyy changed");
  // }, [asd, asdasd]);

  const toggleTechnologies = () => {
    const newTech = activeTechnologies.length === 0 ? technologies : [];
    setActiveTechnologies(newTech);
  };

  const handleTechnologyClick = (name) => {
    const index = activeTechnologies.indexOf(name);
    if (index === -1) {
      setActiveTechnologies([...activeTechnologies, name]);
    } else {
      const newTechnologies = [...activeTechnologies];
      newTechnologies.splice(index, 1);
      setActiveTechnologies(newTechnologies);
    }
  };

  const onRemoteClick = () => {
    setFilterState({
      ...filterState,
      remote: !filterState.remote,
    });
  };

  const onPriceRangeClick = () => {
    setFilterState({
      ...filterState,
      priceRange: !filterState.priceRange,
    });
  };

  const onSelectChange = (event) => {
    setFilterState({
      ...filterState,
      seniority: event.target.value,
    });
  };

  console.log("render");

  return (
    <div className="App">
      <div className="filters">
        <div className="upper-filters">
          <div>
            {positions.map((name) => {
              const className = activePosition === name ? "active" : "";
              return (
                <button
                  className={className}
                  key={name}
                  onClick={() => setActivePosition(name)}
                >
                  {name}
                </button>
              );
            })}
          </div>
          <select onChange={onSelectChange} value={filterState.seniority}>
            <option value="all">All</option>
            <option value="junior">Junior</option>
            <option value="mid">Mid</option>
            <option value="senior">Senior</option>
          </select>
        </div>
        <div className="lower-filters">
          <div className="technologies">
            <button onClick={toggleTechnologies}>
              {activeTechnologies.length === 0 ? "Select All" : "Clear All"}
            </button>
            {technologies.map((name) => {
              const className = activeTechnologies.includes(name)
                ? "active"
                : "";
              return (
                <button
                  className={className}
                  key={name}
                  onClick={() => handleTechnologyClick(name)}
                >
                  {name}
                </button>
              );
            })}
          </div>
          <div className="others">
            <button
              onClick={onRemoteClick}
              className={filterState.remote ? "active" : ""}
            >
              100% remote
            </button>
            <button
              onClick={onPriceRangeClick}
              className={filterState.priceRange ? "active" : ""}
            >
              price range
            </button>
            <button>Not in React</button>
          </div>
        </div>
      </div>
      <div className="list">
        <table>
          <thead>
            <tr>
              <td>ID</td>
              <td>NAME</td>
              <td>POSITION</td>
              <td>TECHNOLOGIES</td>
              <td>REMOTE</td>
              <td>PRICE RANGE</td>
            </tr>
          </thead>
          <tbody>
            {offers
              .filter((offer) => {
                if (activePosition && activePosition !== offer.position) {
                  return false;
                }

                const filter = activeTechnologies.every((technology) =>
                  offer.technologies.includes(technology)
                );

                if (!filter) {
                  return filter;
                }

                return true;
              })
              .map(
                ({ id, name, position, technologies, remote, priceRange }) => (
                  <tr>
                    <td>{id}</td>
                    <td>{name}</td>
                    <td>{position}</td>
                    <td>{technologies.join(", ")}</td>
                    <td>{remote.toString()}</td>
                    <td>{priceRange?.join(" - ")}</td>
                  </tr>
                )
              )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default App;
