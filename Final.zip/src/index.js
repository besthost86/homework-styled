import React, { useState } from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import reportWebVitals from "./reportWebVitals";

const dummyOffers = [
  {
    id: 1,
    name: "Frontend Dev",
    position: "Game",
    technologies: ["Javascript", "React"],
    remote: false,
    priceRange: [5000, 10000],
  },
  {
    id: 2,
    name: "Principal Dev",
    position: "Analytics",
    technologies: ["React"],
    remote: true,
    priceRange: null,
  },
  {
    id: 3,
    name: "Fullstack Dev",
    position: "Game",
    technologies: ["Javascript", "Vue"],
    remote: false,
    priceRange: null,
  },
  {
    id: 4,
    name: "Backend Dev",
    position: "Testing",
    technologies: ["Svelte", "React"],
    remote: true,
    priceRange: [3000, 8000],
  },
];

const root = ReactDOM.createRoot(document.getElementById("root"));

const AppWrapper = ({ children }) => {
  const [showApp, setShowApp] = useState(false);

  return (
    <div>
      <button onClick={() => setShowApp(!showApp)}>Show App</button>
      {showApp && children}
    </div>
  );
};
root.render(
  <React.StrictMode>
    <div>
      <AppWrapper>
        <App offers={dummyOffers} />
      </AppWrapper>
    </div>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
